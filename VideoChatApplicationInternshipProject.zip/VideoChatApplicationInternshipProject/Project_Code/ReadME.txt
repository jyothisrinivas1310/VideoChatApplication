# P2P Video Chat with JavaScript / WebRTC

> [https://www.youtube.com/watch?v=ieBtXwHvoNk](https://www.youtube.com/watch?v=ieBtXwHvoNk)

Install [io.js](https://iojs.org/en/index.html).

Within this folder run the terminal command `npm install` to install the
`dependencies` and `devDependencies`.

Then run `npm start` to run the app.
